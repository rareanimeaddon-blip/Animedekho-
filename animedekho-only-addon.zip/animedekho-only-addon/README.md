# AnimeDekho-only provider source bundle

This bundle contains the complete AnimeDekho provider directory extracted from the addon ZIP supplied in this conversation, plus the shared utility files directly imported by that provider.

## Contents
- `src/providers/animedekho/animedekho.ts` — AnimeDekho search/catalog/metadata/episode and watch-page logic
- `src/providers/animedekho/animedekho-proxy.ts` — provider proxy routes
- `src/providers/animedekho/domain.js` and `domain.d.ts` — host/domain helpers
- `src/providers/animedekho/extractors/` — all AnimeDekho-specific host extractors
- `src/utils/fetch.ts`, `src/utils/unpack-eval.ts` — shared fetch and script parsing helpers
- `src/lib/logger.ts`, `src/lib/base-path.ts` — shared imports required by provider modules

## Important integration note
This is a source bundle, not a standalone runnable Stremio addon. The original project routes/configuration and the rest of its application are intentionally not included because you asked for AnimeDekho only. To run it inside the original project, preserve the original directory paths and its existing route registration.

The code is extracted as-is; it has not been modified to claim that the current live AnimeDekho episode returns playable sources, and no live playback test is implied.
