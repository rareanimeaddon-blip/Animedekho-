import * as cheerio from "cheerio";
import { fetchDoc, fetchText } from "../../utils/fetch.js";
import { logger } from "../../lib/logger.js";
import {
  ANIMEDEKHO_BASE_URL,
  isAnimeDekhoContentPage,
  isAnimeDekhoOwnedPath,
  isAnimeDekhoUrl,
} from "./domain.js";

export const BASE_URL = ANIMEDEKHO_BASE_URL;

export interface SearchResult {
  id: string;
  title: string;
  poster: string | null;
  background: string | null;
  url: string;
  type: "movie" | "series";
  year: string | null;
  description: string | null;
  genres: string[];
}

export interface Episode {
  id: string;
  title: string;
  poster: string | null;
  url: string;
  season: number | null;
  episode: number | null;
}

export interface MediaMeta {
  id: string;
  title: string;
  poster: string | null;
  plot: string | null;
  year: number | null;
  type: "movie" | "series";
  url: string;
  mediaType: number;
  genres: string[];
  episodes?: Episode[];
}

function encodeId(url: string, mediaType: number): string {
  return "animedekho:" + Buffer.from(JSON.stringify({ url, mediaType })).toString("base64url");
}

function decodeId(id: string): { url: string; mediaType: number } | null {
  try {
    return JSON.parse(Buffer.from(id.replace("animedekho:", ""), "base64url").toString("utf8"));
  } catch { return null; }
}

export { encodeId, decodeId };

function fixImageUrl(src: string | undefined, fallback: string | null = null): string | null {
  if (!src) return fallback;
  if (src.startsWith("data:")) return fallback;
  if (src.startsWith("http")) return src;
  if (src.startsWith("//")) return "https:" + src;
  return fallback;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function parseArticle($: ReturnType<typeof cheerio.load>, el: any): SearchResult | null {
  const root = $(el);
  const card = root.is("a.dgt-card")
    ? root
    : root.find("a.dgt-card, a.lnk-blk").first();
  const href = card.attr("href") || root.find("a.lnk-blk").attr("href");
  // Accept the current canonical host and legacy URLs, but never off-site or lookalike hosts.
  if (!href || !isAnimeDekhoContentPage(href)) return null;
  const rawTitle =
    card.find(".dgt-card__title").text().trim() ||
    root.find("header h2").text().trim() ||
    root.find("h2.entry-title").text().trim() ||
    root.find("h2").text().trim() ||
    "Unknown";
  const title = cleanTitle(rawTitle);
  let poster =
    card.find("img").attr("data-src") ||
    card.find("img").attr("data-lazy-src") ||
    card.find("img").attr("src") ||
    root.find("div.post-thumbnail figure img").attr("src") ||
    root.find(".post-thumbnail figure img").attr("src") ||
    root.find("figure img").attr("src") ||
    root.find("img").attr("src");
  if (poster?.startsWith("data:")) {
    poster =
      card.find("img").attr("data-lazy-src") ||
      card.find("img").attr("data-src") ||
      root.find("figure img").attr("data-lazy-src") ||
      root.find("img").attr("data-lazy-src") ||
      root.find("figure img").attr("data-src") ||
      root.find("img").attr("data-src");
  }
  const isMovie = href.includes("/movies/") || href.includes("/movie/") || href.includes("/movie-hindi/");
  const mediaType = isMovie ? 1 : 2;
  const posterUrl = fixImageUrl(poster);

  const yearRaw =
    card.find(".dgt-card__meta").text().trim() ||
    root.find("span.year").first().text().trim();
  const year = yearRaw.match(/\b(?:19|20)\d{2}\b/)?.[0] || null;

  const description = root.find("div.entry-content p").first().text().trim() || null;

  const genres: string[] = [];
  root.find(".details-lst li").each((_, li) => {
    const label = root.find(li).find("span").first().text().trim();
    if (label === "Genres") {
      root.find(li).find("a").each((_, a) => {
        const g = root.find(a).text().trim();
        if (g) genres.push(g);
      });
    }
  });

  return {
    id: encodeId(href, mediaType),
    title,
    poster: posterUrl,
    background: posterUrl,
    url: href,
    type: isMovie ? "movie" : "series",
    year,
    description,
    genres,
  };
}

export async function search(query: string): Promise<SearchResult[]> {
  logger.info({ query }, "AnimeDekho search");
  try {
    // animedekho.app's search endpoint is genuinely slow for broad/popular
    // queries (e.g. "Naruto" observed taking ~20s server-side) — the shared
    // fetch default of 10s aborts these before the site ever responds,
    // silently turning a real result into "no streams". Give search specifically
    // more room, and retry once on a timeout/network error before giving up.
    let $;
    try {
      $ = await fetchDoc(`${BASE_URL}/search/${encodeURIComponent(query)}`, { timeout: 25000 });
    } catch (err) {
      logger.warn({ query, err }, "AnimeDekho search: first attempt failed, retrying once");
      $ = await fetchDoc(`${BASE_URL}/search/${encodeURIComponent(query)}`, { timeout: 25000 });
    }
    const results: SearchResult[] = [];
    // Only look inside ul[data-results] — the generic "article" fallback
    // grabs sidebar/related-posts content and returns wrong items
    const $cards = $("a.dgt-card");
    if ($cards.length > 0) {
      $cards.each((_, el) => {
        const r = parseArticle($, el);
        if (r) results.push(r);
      });
    }
    const $results = $("ul[data-results] article");
    if (results.length === 0 && $results.length > 0) {
      $results.each((_, el) => {
        const r = parseArticle($, el);
        if (r) results.push(r);
      });
    } else if (results.length === 0) {
      // Some page variants wrap results differently — try common content containers only
      $(".site-main article, #main article, .search-results article").each((_, el) => {
        const r = parseArticle($, el);
        if (r) results.push(r);
      });
    }
    logger.info({ query, count: results.length }, "search results");
    return results;
  } catch (err) { logger.error({ query, err }, "search error"); return []; }
}

const CATALOG_PATH_MAP: Record<string, string> = {
  "animedekho-series": "/series-hindi/",
  "animedekho-movies": "/movie-hindi/",
  "animedekho-anime": "/category/anime/",
  "animedekho-cartoon": "/category/cartoon/",
  "animedekho-crunchyroll": "/category/crunchyroll/",
  "animedekho-hindi-dub": "/category/hindi-dub/",
  "animedekho-tamil": "/category/tamil/",
  "animedekho-telugu": "/category/telugu/",
  "animedekho-action": "/category/action/",
  "animedekho-adventure": "/category/adventure/",
  "animedekho-comedy": "/category/comedy/",
  "animedekho-drama": "/category/drama/",
  "animedekho-fantasy": "/category/fantasy/",
  "animedekho-romance": "/category/romance/",
  "animedekho-horror": "/category/horror/",
  "animedekho-mystery": "/category/mystery/",
  "animedekho-supernatural": "/category/supernatural/",
  "animedekho-isekai": "/category/isekai/",
  "animedekho-slice-of-life": "/category/slice-of-life/",
  "animedekho-shounen": "/category/shounen/",
  "animedekho-mecha": "/category/mecha/",
  "animedekho-kids": "/category/kids/",
};

const GENRE_PATH_MAP: Record<string, string> = {
  "Anime": "/category/anime/",
  "Cartoon": "/category/cartoon/",
  "Animation": "/category/animation/",
  "Crunchyroll": "/category/crunchyroll/",
  "Hindi Dub": "/category/hindi-dub/",
  "Tamil": "/category/tamil/",
  "Telugu": "/category/telugu/",
  "Action": "/category/action/",
  "Adventure": "/category/adventure/",
  "Comedy": "/category/comedy/",
  "Drama": "/category/drama/",
  "Fantasy": "/category/fantasy/",
  "Romance": "/category/romance/",
  "Horror": "/category/horror/",
  "Mystery": "/category/mystery/",
  "Sci-Fi": "/category/sci-fi/",
  "Thriller": "/category/thriller/",
  "Supernatural": "/category/supernatural/",
  "Isekai": "/category/isekai/",
  "Slice of Life": "/category/slice-of-life/",
  "Shounen": "/category/shounen/",
  "Mecha": "/category/mecha/",
  "Kids": "/category/kids/",
  "Family": "/category/family/",
};

interface CacheEntry<T> { data: T; expires: number; }
const catalogCache = new Map<string, CacheEntry<SearchResult[]>>();
const CATALOG_TTL = 10 * 60 * 1000;

export async function catalog(catalogId: string, genre?: string, skip = 0, type?: string): Promise<SearchResult[]> {
  let path = CATALOG_PATH_MAP[catalogId] || "/serie/";
  if (genre && GENRE_PATH_MAP[genre]) path = GENRE_PATH_MAP[genre];
  const page = Math.floor(skip / 20) + 1;
  const cacheKey = `${path}::${page}::${type || ""}`;
  const cached = catalogCache.get(cacheKey);
  if (cached && cached.expires > Date.now()) {
    logger.debug({ cacheKey }, "catalog cache hit");
    return cached.data;
  }
  const url = page > 1 ? `${BASE_URL}${path}page/${page}/` : `${BASE_URL}${path}`;
  logger.info({ catalogId, genre, skip, page, url }, "catalog fetch");
  try {
    const $ = await fetchDoc(url);
    let results: SearchResult[] = [];
    const $cards = $("a.dgt-card");
    if ($cards.length > 0) {
      $cards.each((_, el) => { const r = parseArticle($, el); if (r) results.push(r); });
    } else {
      $("article").each((_, el) => { const r = parseArticle($, el); if (r) results.push(r); });
    }
    if (type === "movie") results = results.filter((r) => r.type === "movie");
    if (type === "series") results = results.filter((r) => r.type === "series");
    logger.info({ catalogId, type, count: results.length }, "catalog results");
    catalogCache.set(cacheKey, { data: results, expires: Date.now() + CATALOG_TTL });
    return results;
  } catch (err) { logger.error({ catalogId, err }, "catalog error"); return []; }
}

function parseSeasonEpisodeFromUrl(url: string): { season: number; episode: number } | null {
  const match = url.match(/[-\/](\d+)x(\d+)\/?(?:[?#]|$)/);
  if (match) {
    return { season: parseInt(match[1], 10), episode: parseInt(match[2], 10) };
  }
  return null;
}

async function getCurrentSeriesEpisodes(seriesId: number, season: number): Promise<Episode[]> {
  const endpoint =
    `${BASE_URL}/wp-json/dgt/v1/episodes?series=${encodeURIComponent(String(seriesId))}` +
    `&season=${encodeURIComponent(String(season))}`;
  try {
    const response = await fetchText(endpoint, {
      timeout: 12000,
      headers: { Accept: "application/json", Referer: BASE_URL },
    });
    const payload = JSON.parse(response) as {
      episodes?: Array<{
        season?: number;
        episode?: number;
        name?: string;
        label?: string;
        still?: string;
        url?: string;
      }>;
    };
    if (!Array.isArray(payload.episodes)) return [];
    return payload.episodes.flatMap((item) => {
      const episodeUrl = item.url ? new URL(item.url, BASE_URL).toString() : "";
      const episodeNumber = Number(item.episode);
      if (!episodeUrl || !isAnimeDekhoUrl(episodeUrl) || !Number.isFinite(episodeNumber)) return [];
      return [{
        id: encodeId(episodeUrl, 2),
        title: item.name || item.label || `Episode ${episodeNumber}`,
        poster: fixImageUrl(item.still),
        url: episodeUrl,
        season: Number(item.season) || season,
        episode: episodeNumber,
      }];
    });
  } catch (err) {
    logger.warn({ seriesId, season, err }, "AnimeDekho: current episode API request failed");
    return [];
  }
}

function cleanTitle(raw: string): string {
  return (
    raw
      .replace(/^Watch\s+Online\s+/i, "")
      .split(/\s*[–|]\s*/)[0]!
      .replace(/\s+(?:Movie\s+)?(?:in\s+)?(?:Hindi|Tamil|Telugu|English|Dual)\s+(?:Dubbed?|Sub(?:bed)?|Audio)(?:\s+Free)?.*$/i, "")
      .replace(/\s+\([^)]*(?:Dubbed?|Dub|Sub(?:bed)?|Audio)[^)]*\)\s*$/i, "")
      .replace(/\s+Movie\s+\([^)]+\)\s*$/i, "")
      .replace(/\s*–\s*Watch\s+Online.*$/i, "")
      .replace(/\s*\|\s*AnimeDekho.*$/i, "")
      .trim() || raw.trim()
  );
}

const metaCache = new Map<string, CacheEntry<MediaMeta>>();
const META_TTL = 30 * 60 * 1000;

export async function getMeta(stremioId: string): Promise<MediaMeta | null> {
  const cached = metaCache.get(stremioId);
  if (cached && cached.expires > Date.now()) {
    logger.debug({ stremioId }, "getMeta cache hit");
    return cached.data;
  }
  const decoded = decodeId(stremioId);
  if (!decoded) { logger.warn({ stremioId }, "getMeta: invalid id"); return null; }
  const { url, mediaType } = decoded;
  logger.info({ url, mediaType }, "getMeta fetch");
  try {
    const $ = await fetchDoc(url);
    let currentSnapshot: {
      id?: number;
      title?: string;
      poster?: string;
      genres?: string[];
      year?: number | null;
    } = {};
    const snapshotText =
      $("#dgt-title").attr("data-snapshot") ||
      $("#dgt-watch").attr("data-snapshot") ||
      "";
    try {
      if (snapshotText) currentSnapshot = JSON.parse(snapshotText);
    } catch {
      logger.debug({ url }, "AnimeDekho: current page snapshot was invalid JSON");
    }
    const rawTitle =
      currentSnapshot.title ||
      $(".dgt-h1").first().text().trim() ||
      $("h1.entry-title").text().trim() ||
      $("meta[property='og:title']").attr("content") ||
      "Unknown";
    const title = cleanTitle(rawTitle);
    let poster =
      currentSnapshot.poster ||
      $(".dgt-title img").first().attr("data-src") ||
      $("div.post-thumbnail figure img").attr("src") ||
      $(".post-thumbnail img").first().attr("src") ||
      $("meta[property='og:image']").attr("content") ||
      null;
    if (poster?.startsWith("data:")) poster = $("meta[property='og:image']").attr("content") || null;

    const plot =
      $("div.entry-content p").first().text().trim() ||
      $("meta[name='description']").attr("content") ||
      $("meta[name='twitter:description']").attr("content") ||
      null;

    const yearStr =
      $("span.year").first().text().trim() ||
      $("meta[property='og:updated_time']").attr("content")?.split("-")[0];
    const year = yearStr ? parseInt(yearStr) || null : null;

    const genreSet = new Set<string>();
    $(".details-lst li, .single-details li").each((_, li) => {
      const label = $(li).find("span").first().text().trim();
      if (label === "Genres" || label === "Genre") {
        $(li).find("a").each((_, a) => {
          const g = $(a).text().trim();
          if (g) genreSet.add(g);
        });
      }
    });
    const genres = Array.from(genreSet);

    // Determine type from URL path — most reliable signal
    const isSeriesPage = url.includes("/serie/") || url.includes("/series/") || url.includes("/series-hindi/");
    const isMoviePage  = url.includes("/movies/") || url.includes("/movie/") || url.includes("/movie-hindi/");
    // mediaType in the decoded stremio id is also a reliable hint
    const mediaTypeHint = decoded.mediaType; // 1=movie, 2=series

    // Try multiple selectors for episode lists — AnimeDekho layout varies
    const seasonItems =
      $("ul.seasons-lst li").length > 0 ? $("ul.seasons-lst li") :
      $(".epiitem li, .episodes-list li, .episode-list li, .eplist li, .eps-list li").length > 0
        ? $(".epiitem li, .episodes-list li, .episode-list li, .eplist li, .eps-list li")
        : $([]);

    const hasEpisodes = seasonItems.length > 0;

    // Decide final content type
    const contentType: "movie" | "series" =
      isSeriesPage ? "series" :
      isMoviePage  ? "movie"  :
      mediaTypeHint === 1 ? "movie" :
      mediaTypeHint === 2 ? "series" :
      hasEpisodes  ? "series" : "movie";

    // The current site moved its episode list to a public WordPress REST endpoint.
    // The detail page contains its series ID and season tabs in data attributes.
    if (contentType === "series") {
      const seriesId =
        Number($("#dgt-title").attr("data-series")) ||
        Number(currentSnapshot.id) ||
        Number(($("body").attr("class") || "").match(/\bpostid-(\d+)\b/)?.[1]);
      let seasonTabs: Array<{ season?: number }> = [];
      const tabsText =
        $("#dgt-title").attr("data-tabs") ||
        $("[data-tabs]").first().attr("data-tabs") ||
        "";
      try {
        if (tabsText) seasonTabs = JSON.parse(tabsText);
      } catch {
        logger.debug({ url }, "AnimeDekho: current season tabs were invalid JSON");
      }
      const seasons = [...new Set(
        seasonTabs
          .map((tab) => Number(tab.season))
          .filter((season) => Number.isInteger(season) && season > 0),
      )];
      if (seasons.length === 0) {
        const startUrl = $("#dgt-title").attr("data-start") || $("#dgt-watch-btn").attr("href") || "";
        const firstEpisode = startUrl ? parseSeasonEpisodeFromUrl(startUrl) : null;
        if (firstEpisode) seasons.push(firstEpisode.season || 1);
      }
      if (seriesId > 0 && seasons.length > 0) {
        const episodeGroups = await Promise.all(
          seasons.slice(0, 30).map((season) => getCurrentSeriesEpisodes(seriesId, season)),
        );
        const currentEpisodes = episodeGroups.flat();
        if (currentEpisodes.length > 0) {
          const result: MediaMeta = {
            id: stremioId,
            title,
            poster,
            plot,
            year: Number(currentSnapshot.year) || year,
            type: "series",
            url,
            mediaType: 2,
            genres: [...new Set([...genres, ...(currentSnapshot.genres || [])])],
            episodes: currentEpisodes,
          };
          metaCache.set(stremioId, { data: result, expires: Date.now() + META_TTL });
          logger.info(
            { title, seriesId, seasons: seasons.length, episodes: currentEpisodes.length },
            "AnimeDekho: loaded episodes from current site API",
          );
          return result;
        }
      }
    }

    if (!hasEpisodes) {
      const result: MediaMeta = {
        id: stremioId, title, poster, plot, year,
        type: contentType,
        url,
        mediaType: contentType === "series" ? 2 : 1,
        genres,
        episodes: [],
      };
      metaCache.set(stremioId, { data: result, expires: Date.now() + META_TTL });
      return result;
    }

    const episodes: Episode[] = [];
    const episodeCountPerSeason: Record<number, number> = {};
    seasonItems.each((_, el) => {
      const episodeHref = $(el).find("a").attr("href");
      if (!episodeHref) return;
      const epTitle = $(el).find("h3.title").clone().children().remove().end().text().trim()
        || $(el).find("h3, .ep-title, .title").first().text().trim();
      const epPoster = fixImageUrl(
        $(el).find("div > div > figure > img").attr("src") ||
        $(el).find("figure img").attr("src") ||
        $(el).find("img").attr("src")
      );
      const seasonSpanText = $(el).find("h3.title > span, .season-label, [class*='season']").text();
      const seasonMatch = seasonSpanText.match(/S(\d+)/i);

      const urlParsed = parseSeasonEpisodeFromUrl(episodeHref);

      let season: number;
      let episodeNum: number;

      if (urlParsed) {
        // AnimeDekho sometimes uses season=0 — treat 0 as season 1
        season = urlParsed.season === 0 ? 1 : urlParsed.season;
        episodeNum = urlParsed.episode;
      } else {
        season = seasonMatch ? parseInt(seasonMatch[1]) : 1;
        episodeCountPerSeason[season] = (episodeCountPerSeason[season] || 0) + 1;
        episodeNum = episodeCountPerSeason[season];
      }

      const episodeId = encodeId(episodeHref, 2);
      episodes.push({
        id: episodeId,
        title: epTitle || `Episode ${episodeNum}`,
        poster: epPoster,
        url: episodeHref,
        season,
        episode: episodeNum,
      });
    });

    const result: MediaMeta = {
      id: stremioId, title, poster, plot, year,
      type: "series", url, mediaType: 2, genres, episodes,
    };
    metaCache.set(stremioId, { data: result, expires: Date.now() + META_TTL });
    return result;
  } catch (err) {
    logger.error({ url, err }, "getMeta error");
    return null;
  }
}

export async function getBodyTermId(url: string): Promise<{ term: string; mediaType: number; text: string } | null> {
  // Primary: scrape body class for postid/term
  try {
    const text = await fetchText(url, { timeout: 7000 });
    const $ = cheerio.load(text);
    const bodyClass = $("body").attr("class") || "";
    const match = bodyClass.match(/(?:term|postid)-(\d+)/);
    if (match) {
      const isMovie = url.includes("/movie/") || url.includes("/movies/") || url.includes("/movie-hindi/") || bodyClass.includes("single-movie");
      logger.info({ url, term: match[1] }, "getBodyTermId: found via body class");
      return { term: match[1], mediaType: isMovie ? 1 : 2, text };
    }
    logger.warn({ url, bodyClass }, "no postid/term found in body class");
  } catch (err) {
    logger.warn({ url, err }, "getBodyTermId: page fetch failed, trying WP REST API");
  }

  // Fallback: WordPress REST API — works even when Cloudflare blocks the page
  try {
    const slug = url.replace(/\/$/, "").split("/").pop() || "";
    if (!slug) return null;
    // Try both 'posts' (episodes/movies) endpoint types
    for (const wpType of ["posts", "pages"]) {
      const apiUrl = `${BASE_URL}/wp-json/wp/v2/${wpType}?slug=${encodeURIComponent(slug)}&_fields=id,type,link`;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      try {
        const res = await fetch(apiUrl, {
          headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36", Accept: "application/json" },
          signal: controller.signal,
        });
        clearTimeout(timer);
        if (!res.ok) continue;
        const data = await res.json() as Array<{ id: number; type?: string; link?: string }>;
        if (Array.isArray(data) && data[0]?.id) {
          const postId = String(data[0].id);
          const isMovie = url.includes("/movie/") || url.includes("/movies/") || url.includes("/movie-hindi/") || data[0].type === "movie";
          logger.info({ url, slug, postId }, "getBodyTermId: found via WP REST API");
          return { term: postId, mediaType: isMovie ? 1 : 2, text: "" };
        }
      } catch (innerErr) {
        clearTimeout(timer);
        logger.debug({ apiUrl, err: innerErr }, "getBodyTermId WP REST API attempt failed");
      }
    }
  } catch (err) {
    logger.error({ url, err }, "getBodyTermId WP REST API fallback error");
  }

  return null;
}

export interface AnimeDekhoWatchSource {
  server: string;
  embed: string;
  quality?: string;
}

/**
 * The current AnimeDekho player is populated from its public watch endpoint;
 * the episode HTML itself only contains an empty player shell.
 */
export async function getAnimeDekhoWatchSources(episodeUrl: string): Promise<AnimeDekhoWatchSource[]> {
  if (!isAnimeDekhoUrl(episodeUrl)) return [];
  try {
    const html = await fetchText(episodeUrl, { timeout: 10000 });
    const $ = cheerio.load(html);
    const player = $("#dgt-watch");
    const postId = Number(player.attr("data-title"));
    const episodeId = Number(player.attr("data-term"));
    if (!Number.isInteger(postId) || postId <= 0 || !Number.isInteger(episodeId) || episodeId <= 0) {
      return [];
    }

    const response = await fetch(`${BASE_URL}/wp-json/dgt/v1/watch`, {
      method: "POST",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        Accept: "application/json",
        "Content-Type": "application/json",
        Origin: BASE_URL,
        Referer: episodeUrl,
      },
      body: JSON.stringify({ post_id: postId, episode_id: episodeId }),
      signal: AbortSignal.timeout(12000),
    });
    if (!response.ok) {
      logger.warn({ status: response.status, episodeId }, "AnimeDekho: watch endpoint returned an error");
      return [];
    }

    const payload = await response.json() as {
      gated?: boolean;
      hours?: number;
      sources?: Array<{
        server?: string;
        kind?: string;
        embed?: string;
        quality?: string;
        show_embed?: boolean;
      }>;
    };
    if (payload.gated) {
      logger.warn(
        { episodeId, hours: payload.hours },
        "AnimeDekho: site access gate is required before watch sources are available",
      );
      return [];
    }

    const sources: AnimeDekhoWatchSource[] = [];
    for (const source of payload.sources || []) {
      if (source.kind !== "embed" || source.show_embed === false || !source.server || !source.embed) continue;
      const embed = new URL(source.embed, BASE_URL).toString();
      if (!isAnimeDekhoUrl(embed)) continue;
      sources.push({ server: source.server, embed, quality: source.quality });
    }
    logger.info({ episodeId, sourceCount: sources.length }, "AnimeDekho: current watch sources loaded");
    return sources;
  } catch (err) {
    logger.warn({ episodeUrl, err }, "AnimeDekho: current watch endpoint failed");
    return [];
  }
}

const EMBED_ERROR_MARKERS = ["Server Error (Link)", "server error", "Report to Admin", "File Not Found", "file not found", "Video Not Found", "This video has been removed"];
function isEmbedErrorPage(html: string): boolean { return EMBED_ERROR_MARKERS.some((m) => html.includes(m)); }

function decodeServerButtons(html: string): Array<{ url: string; name: string }> {
  const results: Array<{ url: string; name: string }> = [];
  const $doc = cheerio.load(html);
  // Primary selector: server tab buttons with data-src and data-option
  $doc("a[data-src][data-option]").each((_, el) => {
    const b64 = $doc(el).attr("data-src") || "";
    const name = $doc(el).find("span.num").text().trim() || $doc(el).text().trim() || "";
    if (!b64) return;
    try {
      // The site sometimes HTML-escapes query separators before base64-encoding
      // the URL. Decode them after base64 so trid/trtype reach the provider intact.
      const decoded = Buffer.from(b64, "base64")
        .toString("utf8")
        .replace(/&amp;/gi, "&")
        .replace(/&#0*38;/gi, "&")
        .replace(/&#x0*26;/gi, "&");
      if (isAnimeDekhoUrl(decoded)) {
        results.push({ url: decoded, name });
      }
    } catch {}
  });
  return results;
}

/**
 * Parses the episode/movie page HTML to determine which servers are listed.
 * Returns the NeoCDN flag, the exact myth player URL (with the correct trdekho slot
 * for this page — varies per show), and the trdekho= indices present on the page
 * (excluding HydraX/abyssplayer). Use this to avoid blind 0-24 trdekho scanning
 * which causes wrong CDN content from non-existent slots.
 *
 * IMPORTANT: neoCdnMythUrl must be passed directly to getNeoCdnStreams — it contains
 * the HydraX trdekho slot index for this specific show (e.g. trdekho=0 for Liar Game,
 * trdekho=1 for Shinchan). Using a hardcoded trdekho=1 breaks NeoCDN for any show
 * where HydraX is mapped to a different slot.
 */
function hasEmbedSlot(url: string): boolean {
  try {
    const parsed = new URL(url, BASE_URL);
    return ["trembed", "trdekho"].some((key) =>
      /^\d+$/.test(parsed.searchParams.get(key) ?? ""),
    );
  } catch {
    return false;
  }
}

export function parsePageServers(html: string): {
  hasNeocdn: boolean;
  neoCdnMythUrl: string | null;
  embedSlotUrls: string[];
  hydraxSlotUrl: string | null;
} {
  const buttons = decodeServerButtons(html);
  let hasNeocdn = false;
  let neoCdnMythUrl: string | null = null;
  const embedSlotUrls: string[] = [];
  let hydraxSlotUrl: string | null = null;
  for (const { url, name } of buttons) {
    if (url.includes("/aaa/myth/play.php")) {
      hasNeocdn = true;
      neoCdnMythUrl = url.startsWith("http") ? url : `${BASE_URL}${url}`;
      continue;
    }
    const lname = name.toLowerCase();
    // HydraX (AnimeDekho's label for the Abyss player) is special-cased like NeoCDN:
    // its embed slot is kept out of the generic slot URL list and resolved
    // separately (see getAbyssSourcesCached) because Abyss CDN links are short-lived /
    // limited-use and must be re-derived fresh at play time, not cached like other servers.
    if (lname.includes("hydrax") || lname.includes("abyss")) {
      if (hasEmbedSlot(url)) hydraxSlotUrl = url;
      continue;
    }
    if (hasEmbedSlot(url) && !embedSlotUrls.includes(url)) embedSlotUrls.push(url);
  }
  return { hasNeocdn, neoCdnMythUrl, embedSlotUrls, hydraxSlotUrl };
}

export async function getVidStreamIframes(episodeUrl: string): Promise<{ iframes: string[]; hasNeocdn: boolean; neoCdnMythUrl: string | null; embedSlotUrls: string[]; hydraxSlotUrl: string | null }> {
  const empty = { iframes: [] as string[], hasNeocdn: false, neoCdnMythUrl: null as string | null, embedSlotUrls: [] as string[], hydraxSlotUrl: null as string | null };
  try {
    const html = await fetchText(episodeUrl, { timeout: 7000, headers: { Cookie: "toronites_server=vidstream" } });
    const $ = cheerio.load(html);
    const providerUrls: string[] = [];
    const seen = new Set<string>();

    // Collect any static server iframe already rendered on the page (active server embed)
    $("iframe.serversel[src], iframe[src]").each((_, el) => {
      const src = ($(el).attr("src") || "").trim();
      if (!src) return;
      const normalized = src.startsWith("//") ? "https:" + src : src;
      if (isAnimeDekhoOwnedPath(normalized, "/embed/") && !seen.has(normalized)) { seen.add(normalized); providerUrls.push(normalized); }
    });

    // Parse server buttons — the ground truth of which players exist on this page.
    // The site uses both `trembed` (current) and `trdekho` (legacy) slot params.
    const { hasNeocdn, neoCdnMythUrl, embedSlotUrls, hydraxSlotUrl } = parsePageServers(html);
    const serverButtons = decodeServerButtons(html);
    logger.info(
      { episodeUrl, servers: serverButtons.map((s) => s.name), embedSlotUrls, hasNeocdn, neoCdnMythUrl, hydraxSlotUrl },
      "AnimeDekho: page server buttons",
    );

    // Add direct, non-slot, non-NeoCDN, non-HydraX embed URLs from the server button list.
    // HydraX (Abyss) is handled separately via hydraxSlotUrl + getAbyssSourcesCached.
    for (const { url, name } of serverButtons) {
      if (seen.has(url)) continue;
      if (url.includes("/aaa/myth/play.php")) continue; // NeoCDN: handled by getNeoCdnStreams
      const lname = name.toLowerCase();
      if (url.includes("abyssplayer.com") || url.includes("abysscdn.com") || lname.includes("hydrax") || lname.includes("abyss")) continue;
      if (hasEmbedSlot(url)) continue; // trembed/trdekho slots: handled by getEmbedSlotIframes
      seen.add(url);
      providerUrls.push(url);
    }

    const innerIframes: string[] = [];
    const innerSeen = new Set<string>();
    await Promise.allSettled(providerUrls.map(async (providerUrl) => {
      try {
        const pageHtml = await fetchText(providerUrl, { timeout: 8000, headers: { Referer: episodeUrl, "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" } });
        if (isEmbedErrorPage(pageHtml)) return;
        const $page = cheerio.load(pageHtml);
        $page("iframe[src]").each((_, el) => {
          const src = ($page(el).attr("src") || "").trim();
          if (!src.startsWith("http")) return;
          if (src.includes("youtube.com") || src.includes("youtu.be") || src.includes("vimeo.com") || isAnimeDekhoOwnedPath(src, "/aaa/")) return;
          if (src.includes("abyssplayer.com") || src.includes("abysscdn.com")) return;
          if (!innerSeen.has(src)) { innerSeen.add(src); innerIframes.push(src); }
        });
        if (!innerSeen.size) {
          const cdnPattern = /["'](https?:\/\/[^"'\s]+(?:as-cdn21\.top|zephyrflick\.top|awstream\.net)[^"'\s]*?)["']/g;
          for (const m of pageHtml.matchAll(cdnPattern)) {
            if (!innerSeen.has(m[1])) { innerSeen.add(m[1]); innerIframes.push(m[1]); }
          }
        }
      } catch (err) { logger.debug({ providerUrl, err }, "VidStream provider fetch error"); }
    }));
    return { iframes: innerIframes, hasNeocdn, neoCdnMythUrl, embedSlotUrls, hydraxSlotUrl };
  } catch (err) { logger.error({ episodeUrl, err }, "getVidStreamIframes error"); return empty; }
}

/**
 * Fetches iframes for the exact embed slot URLs listed on the episode/movie page.
 * Keeping the original URL preserves the current `trembed` parameter and legacy
 * `trdekho` parameter instead of reconstructing a stale slot URL.
 */
export async function getEmbedSlotIframes(embedSlotUrls: string[]): Promise<string[]> {
  if (embedSlotUrls.length === 0) return [];
  const results = await Promise.allSettled(
    embedSlotUrls.map((url) => {
      if (!isAnimeDekhoUrl(url)) return Promise.resolve(null);
      return fetchDoc(url, { timeout: 8000 }).then(($) => {
        const src = $("iframe[src]").first().attr("src")?.trim() || $("iframe[data-src]").first().attr("data-src")?.trim();
        if (src && (src.startsWith("http") || src.startsWith("//"))) return src.startsWith("//") ? "https:" + src : src;
        return null;
      });
    })
  );
  const seen = new Set<string>();
  const iframes: string[] = [];
  results.forEach((r, pos) => {
    if (r.status === "fulfilled" && r.value) {
      if (!seen.has(r.value)) { seen.add(r.value); iframes.push(r.value); logger.info({ slotUrl: embedSlotUrls[pos], src: r.value }, "AnimeDekho embed slot iframe found"); }
    }
  });
  return iframes;
}

export interface NeoCdnSource {
  /** Worker-wrapped URL (primary). Uses AnimeDekho's Cloudflare Worker to proxy the raw trycloudflare URL. */
  url: string;
  /** Raw trycloudflare.com URL before worker wrapping. */
  rawUrl?: string;
  /** The myth player URL this source was resolved from. Used by /adneoproxy to re-fetch the
   *  current live CF Worker URL at play time — immune to worker rotation. */
  mythUrl?: string;
  size: string;
  type: string;
}

/**
 * Fetches NeoCDN streams for an episode via animedekho.app/aaa/myth/play.php.
 *
 * Flow:
 *  1. Build myth/play.php URL wrapping the trdekho=1 endpoint for the given term.
 *  2. Fetch with toronites_server=vidstream cookie (same unlock mechanism as VidStream).
 *  3. Extract the /aaa/myth/fetch.php?id=... from the inline script.
 *  4. Fetch that endpoint — returns JSON { sources: [{url, size, type}] }.
 *  5. Sources are direct Cloudflare Tunnel MP4 URLs (360p, 720p).
 *
 * Fetches NeoCDN (myth player) streams using the full myth URL parsed directly
 * from the page's NeoCDN server button. The myth URL encodes the HydraX trdekho
 * slot for this specific show — do NOT reconstruct it with a hardcoded trdekho=1,
 * as the HydraX slot varies per show (e.g. trdekho=0 for Liar Game).
 */
export async function getNeoCdnStreams(
  mythUrl: string,
  referer: string,
): Promise<NeoCdnSource[]> {
  try {
    const mythHtml = await fetchText(mythUrl, {
      timeout: 12000,
      headers: {
        Cookie: "toronites_server=vidstream",
        Referer: referer,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
    });

    const fetchId = mythHtml.match(/myth\/fetch\.php\?id=([^"'\s\\]+)/)?.[1];
    if (!fetchId) {
      logger.warn({ mythUrl }, "getNeoCdnStreams: no fetch ID in myth player");
      return [];
    }

    // Prefer the worker URL embedded in the myth player page — AnimeDekho maintains
    // it themselves and update it when it rotates, so it is always authoritative.
    // Fall back to the last-known-good hardcoded URL only when the page provides none.
    //
    // Background: a dead CF Worker still responds 2xx to HEAD requests (Cloudflare
    // handles HEAD at the edge before the Worker script runs), so we cannot rely on
    // a HEAD probe to validate the worker. Using the page's own URL is more reliable
    // than keeping a hardcoded fallback that can silently go stale.
    const FALLBACK_WORKER_URL = "https://jolly-salad-69ad.zenhashi.workers.dev/?url=";

    const rawPageWorkerUrl = mythHtml.match(/const\s+worker\s*=\s*["']([^"']+)["']/)?.[1]?.trim() ?? "";
    // Accept the page worker only if it looks like a real HTTPS URL ending with "?url=" or similar
    const pageWorkerUrl = rawPageWorkerUrl.startsWith("https://") ? rawPageWorkerUrl : "";
    // Normalise: worker URLs must end with a query-string that the raw URL is appended to
    const normaliseWorker = (w: string) => (w.includes("?") ? w : w + "?url=");
    const ACTIVE_WORKER_URL = pageWorkerUrl
      ? normaliseWorker(pageWorkerUrl)
      : FALLBACK_WORKER_URL;

    logger.info(
      { mythUrl, pageWorkerUrl: pageWorkerUrl || "(none)", activeWorker: ACTIVE_WORKER_URL, usingPage: !!pageWorkerUrl },
      "getNeoCdnStreams: resolved worker URL",
    );

    const fetchEndpoint = `${BASE_URL}/aaa/myth/fetch.php?id=${fetchId}`;
    const fetchRaw = await fetchText(fetchEndpoint, {
      timeout: 12000,
      headers: {
        Referer: mythUrl,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
    });

    const data = JSON.parse(fetchRaw) as { sources?: NeoCdnSource[] };
    if (!data.sources?.length) {
      logger.warn({ mythUrl, fetchId }, "getNeoCdnStreams: empty sources from fetch.php");
      return [];
    }

    // Probe the first source to confirm the trycloudflare tunnel is actually alive.
    // Tunnels are ephemeral and frequently expire — the CF Worker returns 502 when the
    // tunnel host is DNS-dead (ENOTFOUND). We skip NeoCDN entirely rather than surfacing
    // a broken stream to Stremio. This probe goes through the worker since cloud IPs
    // get 403 from trycloudflare directly.
    const firstRawUrl = (data.sources[0] as NeoCdnSource).url;
    try {
      const probe = await fetch(ACTIVE_WORKER_URL + encodeURIComponent(firstRawUrl), {
        method: "HEAD",
        headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" },
        signal: AbortSignal.timeout(8000),
      });
      if (!probe.ok && probe.status !== 206) {
        logger.warn(
          { mythUrl, probeStatus: probe.status, worker: ACTIVE_WORKER_URL.split("?")[0] },
          "getNeoCdnStreams: tunnel probe failed — trycloudflare tunnel is dead, skipping",
        );
        return [];
      }
    } catch (err) {
      logger.warn({ mythUrl, err }, "getNeoCdnStreams: tunnel probe error — skipping NeoCDN streams");
      return [];
    }

    // Wrap every source URL through the active worker so Stremio can play it.
    // Also preserve the original trycloudflare.com URL as `rawUrl`.
    const sources: NeoCdnSource[] = data.sources.map((s) => ({
      ...s,
      rawUrl: s.url,
      mythUrl: mythUrl,
      url: ACTIVE_WORKER_URL + encodeURIComponent(s.url),
    }));

    logger.info({ mythUrl, count: sources.length, activeWorker: ACTIVE_WORKER_URL }, "getNeoCdnStreams: success");
    return sources;
  } catch (err) {
    logger.warn({ mythUrl, err }, "getNeoCdnStreams error");
    return [];
  }
}

// ─── HydraX (Abyss player) ──────────────────────────────────────────────────
//
// AnimeDekho labels this server "HydraX" — it's the site's name for the Abyss
// player (abyssplayer.com / abysscdn.com). Getting a playable link requires:
//   1. Fetch the HydraX trdekho slot — returns a page with an <iframe src>
//      pointing at abyssplayer.com/<id>.
//   2. Fetch that abyssplayer.com page pretending to come from playhydrax.com
//      (Origin/Referer headers) and pull `const datas = "..."` out of its
//      inline scripts — an encrypted blob.
//   3. POST that blob to the public https://enc-dec.app/api/dec-abyss decrypt
//      service, which returns the real source list.
//
// Abyss CDN links appear to be short-lived / limited-use (reused links get
// blocked), so we never cache the final CDN url long-term. Instead we cache
// the whole resolved source list for a short, sliding TTL keyed by the
// (stable, re-derivable) trdekho URL: repeat requests during one continuous
// playback session reuse the same resolved links, but once requests stop for
// CACHE_TTL_MS the entry goes cold and the next request re-runs the entire
// chain from scratch, minting brand new links.

export interface AbyssSource {
  name: string;
  url: string;
  quality: string;
  codec: string;
  size: number;
}

const ABYSS_HEADERS: Record<string, string> = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  Origin: "https://playhydrax.com",
  Referer: "https://playhydrax.com/",
};

interface AbyssCacheEntry { sources: AbyssSource[]; expires: number; }
const abyssCache = new Map<string, AbyssCacheEntry>();
const ABYSS_CACHE_TTL_MS = 60_000;

function abyssQualityFromType(type: string): string {
  const m = type.match(/(\d{3,4})p?/i);
  return m ? `${m[1]}p` : (type || "Unknown");
}

/** Stable-ish key used to re-locate "the same" quality on a later, fresh resolve. */
export function abyssQualityKey(source: AbyssSource, index: number): string {
  const safeQuality = source.quality.replace(/[^a-zA-Z0-9]/g, "");
  const safeCodec = (source.codec || "unknown").replace(/[^a-zA-Z0-9]/g, "");
  return `${safeQuality}-${safeCodec}-${index}`;
}

export function pickAbyssSourceByKey(sources: AbyssSource[], key: string): AbyssSource | null {
  const exact = sources.find((s, i) => abyssQualityKey(s, i) === key);
  if (exact) return exact;
  // Fresh resolves can shuffle order/count slightly; fall back to matching
  // just the quality label before giving up.
  const [qualityPart] = key.split("-");
  const sameQuality = sources.find((s) => s.quality.replace(/[^a-zA-Z0-9]/g, "") === qualityPart);
  return sameQuality ?? sources[0] ?? null;
}

/**
 * Runs the entire HydraX -> Abyss resolution chain from scratch: fetches the
 * trdekho slot, follows its iframe to the abyssplayer.com embed, extracts the
 * encrypted `datas` blob, and decrypts it via enc-dec.app.
 */
async function resolveFreshAbyssSources(trdekhoUrl: string, referer: string): Promise<AbyssSource[]> {
  try {
    const $ = await fetchDoc(trdekhoUrl, {
      timeout: 8000,
      headers: { Cookie: "toronites_server=vidstream", Referer: referer },
    });
    let embedUrl = $("iframe[src]").first().attr("src")?.trim();
    if (embedUrl?.startsWith("//")) embedUrl = "https:" + embedUrl;
    if (!embedUrl || !embedUrl.startsWith("http")) {
      logger.warn({ trdekhoUrl }, "resolveFreshAbyssSources: no embed iframe found on trdekho slot");
      return [];
    }

    const html = await fetchText(embedUrl, { timeout: 10000, headers: ABYSS_HEADERS });
    const $embed = cheerio.load(html);
    const scripts = $embed("script").map((_, el) => $embed(el).html() || "").get().join("\n");
    const match = scripts.match(/const\s+datas\s*=\s*"([^"]*)"/);
    if (!match?.[1]) {
      logger.warn({ embedUrl }, "resolveFreshAbyssSources: no encrypted datas blob found");
      return [];
    }

    const decRes = await fetch("https://enc-dec.app/api/dec-abyss", {
      method: "POST",
      headers: { ...ABYSS_HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify({ text: match[1] }),
      signal: AbortSignal.timeout(10000),
    });
    if (!decRes.ok) {
      logger.warn({ embedUrl, status: decRes.status }, "resolveFreshAbyssSources: enc-dec.app request failed");
      return [];
    }
    const decoded = (await decRes.json()) as {
      result?: { sources?: Array<{ url: string; size: number; type: string; codec: string; status: boolean }> };
    };
    const sources = decoded?.result?.sources ?? [];
    const streams = sources
      .filter((s) => s.status && s.url)
      .map((s) => ({
        name: `HydraX [${(s.codec || "").toUpperCase()}]`,
        url: s.url,
        quality: abyssQualityFromType(s.type),
        codec: s.codec,
        size: s.size,
      }));
    logger.info({ trdekhoUrl, embedUrl, count: streams.length }, "resolveFreshAbyssSources: success");
    return streams;
  } catch (err) {
    logger.warn({ trdekhoUrl, err }, "resolveFreshAbyssSources error");
    return [];
  }
}

/**
 * Returns HydraX/Abyss sources for the given trdekho URL, reusing a resolved
 * result for up to ABYSS_CACHE_TTL_MS of continuous activity (sliding window),
 * and re-running the full resolution chain from scratch once that goes cold.
 */
export async function getAbyssSourcesCached(trdekhoUrl: string, referer: string): Promise<AbyssSource[]> {
  const now = Date.now();
  const cached = abyssCache.get(trdekhoUrl);
  if (cached && cached.expires > now) {
    cached.expires = now + ABYSS_CACHE_TTL_MS; // slide the window forward
    return cached.sources;
  }
  const sources = await resolveFreshAbyssSources(trdekhoUrl, referer);
  if (sources.length > 0) {
    abyssCache.set(trdekhoUrl, { sources, expires: now + ABYSS_CACHE_TTL_MS });
  } else {
    abyssCache.delete(trdekhoUrl);
  }
  return sources;
}

export async function getEpisodePageIframes(episodeUrl: string): Promise<string[]> {
  try {
    const html = await fetchText(episodeUrl, { timeout: 8000 });
    const $ = cheerio.load(html);
    const iframes: string[] = [];
    const seen = new Set<string>();
    $("iframe[src], iframe[data-src]").each((_, el) => {
      const raw = ($(el).attr("src") || $(el).attr("data-src") || "").trim();
      if (!raw) return;
      const src = raw.startsWith("//") ? "https:" + raw : raw;
      if (!src.startsWith("http")) return;
      if (isAnimeDekhoOwnedPath(src, "/aaa/") || src === "about:blank" || src === "javascript:void(0)") return;
      if (src.includes("youtube.com/embed") || src.includes("youtu.be/") || src.includes("player.vimeo.com") || src.includes("facebook.com/plugins") || src.includes("twitter.com/") || src.includes("dailymotion.com/embed")) return;
      if (!seen.has(src)) { seen.add(src); iframes.push(src); }
    });
    return iframes;
  } catch (err) { logger.warn({ episodeUrl, err }, "getEpisodePageIframes error"); return []; }
}
